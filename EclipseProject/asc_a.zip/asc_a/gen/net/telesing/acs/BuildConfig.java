/** Automatically generated file. DO NOT MODIFY */
package net.telesing.acs;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}