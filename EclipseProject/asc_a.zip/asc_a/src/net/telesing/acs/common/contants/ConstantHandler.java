package net.telesing.acs.common.contants;


public class ConstantHandler
{


    public static final int RELOAD_SNS_FILE = 10000001;

    public static final int RESOLUTION_SUCCESS = 10000002;
    public static final int RESOLUTION_FAILURE = 10000003;
    public static final int ISEXIT_HANDLER = 10000004;
    public static final int RESOLUTION_START = 10000005;
    public static final int RESOLUTION_END = 10000006;
    public static final int NO_SETTING_SNS_LIST = 10000007;
    public static final int REST_CHECK = 10000008;
    public static final int SIGNAL_CHANGE = 10000009;

    public static final int SAVE_SETTING = 10000010;


    public static final int CANCEL = 301000;
    public static final int CHANGETIIME = 10000011;




}
