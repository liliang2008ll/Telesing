package net.telesing.acs.bean;

/**
 * Created by Administrator on 2015/11/23.
 */
public class SectionBean {
    private String packageName;
    private String orgName;

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }
}
