#include <stdio.h>
#include <string.h>
#include <jni.h>
#include <stdio.h>
#include "net_telesing_tsdk_tlib_Acomms.h"
#ifdef __cplusplus
extern "C" {
#endif

#include <android/log.h>
#define LOG_TAG "[NDK]"
#define LOGW(a )  __android_log_write(ANDROID_LOG_ERROR,LOG_TAG,a)

JavaVM* globe_JavaVM;
jobject globe_JavaObj;
jclass  globe_JavaClass;

//@JNI�н�JNIEnv�浽ȫ�������g_env
jobject getInstance(JNIEnv* env, jclass obj_class)
{
    jmethodID construction_id = env->GetMethodID(obj_class, "<init>", "()V");
    jobject obj = env->NewObject(obj_class, construction_id);
    return obj;
}

//C++��Ҳ���Ե���Java�ĺ�����ʵ�ַ������£�

//	1����ȡ������jclass cls = env->FindClass
//	2����ȡ�෽����jmethodID mid = env->GetMethodID
//	3����ȡ���Ա������fieldID fid=env->GetFieldID
//	4�����������jobject obj=env->NewObject ��jobectҲ���Դ�Java�㴫������
//	5���������Ա������env->CallXXXMethod(XXXΪJava�����ķ���ֵ����)

//!���Իص�������ʹ��
void ndk_test_call_fnx(char *debug_message){

	//@�½��ַ������ڲ���
	JNIEnv* env_;
	char str1[] = "test1,start....";
	char str2[] = "test2,start....";

	globe_JavaVM->AttachCurrentThread(&env_, NULL);
	//�ҵ�ָ���ĺ�����
	jmethodID mid = env_->GetMethodID(globe_JavaClass, "recogResult", "(Ljava/lang/String;Ljava/lang/String;I)V");
	//���÷���ֵΪvoid�ķ���
	env_->CallVoidMethod(globe_JavaObj, mid,env_->NewStringUTF(str1),env_->NewStringUTF(str2),100);


}
/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    bindCer
 * Signature: (Ljava/lang/String;I)I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_bindCer
  (JNIEnv * input_env, jobject input_obj, jstring input_string, jint inpit_int){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    unbindCer
 * Signature: (Ljava/lang/String;I)I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_unbindCer
  (JNIEnv * input_env, jobject input_obj, jstring input_string, jint inpit_int){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    isBindCer
 * Signature: (Ljava/lang/String;I)I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_isBindCer
  (JNIEnv * input_env, jobject input_obj, jstring input_string, jint inpit_int){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    getSectionsStatus
 * Signature: (Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_getSectionsStatus
  (JNIEnv *input_env, jobject input_obj, jstring input_string){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    genrWave
 * Signature: (Ljava/lang/String;Ljava/lang/String;)[S
 */
JNIEXPORT jshortArray JNICALL Java_net_telesing_tsdk_tlib_Acomms_genrWave
  (JNIEnv *input_env, jobject input_obj, jstring input_string_section, jstring input_string_data){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    startRecog
 * Signature: (Lnet/telesing/tsdk/tlib/Recog_cfg;)I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_startRecog
  (JNIEnv *input_env, jobject input_obj_Recon_cfg, jobject input_obj_cfg){

	JavaVM* globe_JavaVM_;
	jobject globe_JavaObj;
}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    pauseRecog
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_pauseRecog
  (JNIEnv *input_env, jobject input_obj){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    restartRecog
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_restartRecog
  (JNIEnv *input_env, jobject input_obj){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    stopRecog
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_stopRecog
  (JNIEnv *input_env, jobject input_obj){

}
/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    stopRecog
 * Signature: ()I
 */
//!���ģ���ʼ��
//!���浱ǰ�������״̬
//!�ص�����
//!JavaVM* globe_JavaVM;
//!jobject globe_JavaObj;
//!jclass  globe_JavaClass;
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_initRecog
  (JNIEnv *input_env, jobject input_obj){



		//@���������
		input_env->GetJavaVM(&globe_JavaVM);

		//@��ȡȫ�ֵ�obj
		globe_JavaObj = input_env->NewGlobalRef(input_obj);

		//@��ȡȫ�ֵ�
		jclass javaClass = input_env->GetObjectClass(input_obj);

		//@��ȡȫ�ֵ�class
		globe_JavaClass = (jclass)input_env->NewGlobalRef(javaClass);

		ndk_test_call_fnx("test");
}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    writeRecog
 * Signature: ([SI)I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_writeRecog
  (JNIEnv *input_env, jobject input_obj, jshortArray input_shortArray, jint input_int){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    setRecogConfig
 * Signature: (Lnet/telesing/tsdk/tlib/Recog_cfg;)I
 */
JNIEXPORT jint JNICALL Java_net_telesing_tsdk_tlib_Acomms_setRecogConfig
  (JNIEnv *input_env, jobject input_Recong, jobject cfg){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    getRecogConfig
 * Signature: ()Lnet/telesing/tsdk/tlib/Recog_cfg;
 */
JNIEXPORT jobject JNICALL Java_net_telesing_tsdk_tlib_Acomms_getRecogConfig
  (JNIEnv *input_env, jobject Recog_cfg){

}

/*
 * Class:     net_telesing_tsdk_tlib_Acomms
 * Method:    getRecogStatus
 * Signature: ()Lnet/telesing/tsdk/tlib/Recog_status;
 */
JNIEXPORT jobject JNICALL Java_net_telesing_tsdk_tlib_Acomms_getRecogStatus
  (JNIEnv *input_env, jobject Recog_status){

}

#ifdef __cplusplus
}
#endif
