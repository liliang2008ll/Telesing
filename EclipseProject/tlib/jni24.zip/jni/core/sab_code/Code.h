#ifndef  __CODE_H__
#define  __CODE_H__

extern double A00_TD[2048];
extern double A01_TD[2048];
extern double A10_TD[2048];
extern double A11_TD[2048];


extern double B00_TD[2048];
extern double B01_TD[2048];
extern double B10_TD[2048];
extern double B11_TD[2048];

extern double S0_TD[2048];
extern double S1_TD[2048];

#endif
