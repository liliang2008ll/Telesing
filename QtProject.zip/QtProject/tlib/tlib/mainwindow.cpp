﻿/*******************************************************************
 *  Copyright(c) 2015-2017 Nanjing telesing
 *  All rights reserved.
 *
 *  文件名称: core
 *  简要描述: acomms 核心算法对interface接口封装类库
 *
 *  当前版本:1.1
 *  作   者:Lee.liang
 *  日   期:
 *  说   明:
 *
 *  取代版本:1.0
 *  作   者:
 *  日   期:
 *  说   明:
 ******************************************************************/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "./tlib/interface/i4cpp/tlib.h"

//测试用的代码



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->ViewLog->setText("start....");
    ACOMMS acomms;


}

MainWindow::~MainWindow()
{
    delete ui;
}
